INSERT INTO Usuarios_has_Distritos VALUES (3,10201);
INSERT INTO Usuarios_has_Distritos VALUES (3,10202);
INSERT INTO Usuarios_has_Distritos VALUES (3,10203);
