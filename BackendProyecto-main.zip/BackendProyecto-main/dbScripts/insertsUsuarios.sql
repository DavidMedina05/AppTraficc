INSERT INTO Usuarios (NivelAcceso, Username, Password) VALUES (0,"[Usuario Eliminado]", "*");
INSERT INTO Usuarios (NivelAcceso, Username, Password) VALUES (1,"Jorge Bastos","culto");
INSERT INTO Usuarios (NivelAcceso, Username, Password) VALUES (2,"Hoshimachi Suisei","kyoumokawaii");
INSERT INTO Usuarios (NivelAcceso, Username, Password) VALUES (3,"Pipkin Pippa","mold");
INSERT INTO Usuarios (NivelAcceso, Username, Password) VALUES (4,"Eiai Nano","rentarou");
