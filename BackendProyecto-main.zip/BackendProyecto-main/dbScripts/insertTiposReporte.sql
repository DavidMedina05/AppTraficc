INSERT INTO TipoReporte VALUES (1,"Hueco");
INSERT INTO TipoReporte VALUES (2,"Calle Bloqueada");
INSERT INTO TipoReporte VALUES (3,"Deslizamiento");
INSERT INTO TipoReporte VALUES (4,"Inundacion");
INSERT INTO TipoReporte VALUES (5,"Infraestructura Peligrosa");
INSERT INTO TipoReporte VALUES (6,"Otro");
--en areas rurales de guanacaste es comun que la gente use caballos como transporte
INSERT INTO TipoReporte Values (7,"Caballo Muerto Bloqueando Calle");
INSERT INTO TipoReporte Values (8,"Vehiculo Bloqueando Calle");
