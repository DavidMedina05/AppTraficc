﻿namespace TraficoCRFront;

public class NivelAcceso
{
    public int nivelAcceso { get; set; }
}