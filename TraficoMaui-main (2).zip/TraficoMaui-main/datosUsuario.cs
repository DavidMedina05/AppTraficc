﻿namespace TraficoCRFront;

public class datosUsuario
{
    public string username { get; set; }
    public int nivelAcceso { get; set; }
    public datosUsuario(){}
}